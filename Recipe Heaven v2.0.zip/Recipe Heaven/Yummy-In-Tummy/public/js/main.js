//To Get Random Recipe
var alert4 = document.getElementById("alert-4");
for (let index = 0; index < 12; index++) {
  fetch(`https://www.themealdb.com/api/json/v1/1/random.php`)
    .then((response) => response.json())
    .then((data) => {
      // console.log(data);
      let html = "";
      if (data.meals) {
        data.meals.forEach((meal) => {
          html += `

                <div class="row" data-id="${meal.idMeal}">
                  <div class="max-w-[22rem] bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                  <a href="#">
                      <img class="rounded-t-lg" src="${meal.strMealThumb}" alt="${meal.idMeal}" />
                  </a>
                  <div class="p-5">
                      <a href="#">
                          <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">${meal.strMeal}</h5>
                      </a>
                      <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Area: ${meal.strArea}, Category: ${meal.strCategory}.</p>
                      <a href="#"   id="myBtn" onclick="popup_Menu()"class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                          Read more
                          <svg aria-hidden="true" class="w-4 h-4 ml-2 -mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                      </a>
                  </div>
                </div>
              </div>
                `;
        });
      }
      $("#meal").append(html);
    })
    .catch((error) => {
      //custom alert

      modal.innerHTML = `
      <div id="alert-4" class="hidden flex p-4 mb-4 text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300" role="alert">
      <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
      <span class="sr-only">Info</span>
      <div class="ml-3 text-sm font-medium">
      <span class="font-medium">Danger alert!</span><br>Failed in geting Random Recipets From DataBase.<br>Check your internet connection or Reload Page.
      </div>
      <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-yellow-50 text-yellow-500 rounded-lg focus:ring-2 focus:ring-yellow-400 p-1.5 hover:bg-yellow-200 inline-flex h-8 w-8 dark:bg-gray-800 dark:text-yellow-300 dark:hover:bg-gray-700" data-dismiss-target="#alert-4" aria-label="Close">
        <span class="sr-only">Close</span>
        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
      </button>
    </div>
      <div class="modal-content">
      <div class="flex p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
      <svg aria-hidden="true" class="flex-shrink-0 inline w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
      <span class="sr-only">Info</span>
      <div>
        <span class="font-medium">Danger alert!</span><br>Failed in geting Random Recipets From DataBase.<br>Check your internet connection or Reload Page.
      </div>
    </div>
          </div>
            `;
      modal.style.display = "block";
    });
}

//Search for Recipe
let food = {
  get_ingredients: function () {
    var get1 = document.getElementById("search-navbar").value;
    var get2 = document.getElementById("search").value;

    var x = "";
    if (get1 == "") {
      x = get2;
    } else {
      x = get1;
    }
    if (x.length == 0) {
      modal.innerHTML = `
      <div class="modal-content">
      <div class="flex p-4 mb-4 text-sm text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300" role="alert">
      <svg aria-hidden="true" class="flex-shrink-0 inline w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
      <span class="sr-only">Info</span>
      <div>
        <span class="font-medium">Warning alert!</span> Please enter a ingredient and try submitting again.
      </div>
    </div>
            `;
      modal.style.display = "block";
      // alert("Please enter a Some data");
      return;
    } else {
      // console.log(x);
      fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${x}`)
        .then((response) => response.json())
        .then((data) => {
          // console.log(data);
          let html = "";
          if (data.meals) {
            data.meals.forEach((meal) => {
              html += `

              <div class="row" data-id="${meal.idMeal}">
              <div class="max-w-[22rem] bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
              <a href="#">
                  <img class="rounded-t-lg" src="${meal.strMealThumb}" alt="${meal.idMeal}" />
              </a>
              <div class="p-5">
                  <a href="#">
                      <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">${meal.strMeal}</h5>
                  </a>
                  <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Area: ${meal.strArea}, Category: ${meal.strCategory}.</p>
                  <a id="myBtn" href="#" onclick="popup_Menu()" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                      Read more
                      <svg aria-hidden="true" class="w-4 h-4 ml-2 -mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                  </a>
              </div>
            </div>
          </div>
                    `;
            });
            $("#meal").html(html);
          } else {
            modal.innerHTML = `
            <div class="modal-content">
            <div class="flex p-4 mb-4 text-sm text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300" role="alert">
            <svg aria-hidden="true" class="flex-shrink-0 inline w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
            <span class="sr-only">Info</span>
            <div>
              <span class="font-medium">Warning alert!</span> Cannot find Recipe in DataBase.
            </div>
          </div>

                </div>
                  `;
            modal.style.display = "block";
          }
        })
        .catch((error) => {
          modal.innerHTML = `
          <div class="modal-content">
          <div class="flex p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
          <svg aria-hidden="true" class="flex-shrink-0 inline w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
          <span class="sr-only">Info</span>
          <div>
            <span class="font-medium">Danger alert!</span><br>Failed in geting Random Recipets From DataBase.<br>Check your internet connection or Reload Page.
          </div>
        </div>
              </div>
                `;
          modal.style.display = "block";
        });
    }
  },
};

//Event "Enter key"
document.addEventListener("keyup", (event) => {
  if (event.keyCode === 13) {
    food.get_ingredients();
  }
});

// Popup meun when click on Read more
var modal = document.getElementById("myModal");
function popup_Menu() {
  let mealitem = event.target.parentElement.parentElement.parentElement;
  // console.log(mealitem.dataset.id);
  $.getJSON(
    `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${mealitem.dataset.id}`,
    function (data) {
      // console.log(data);
      
        let Ingredient = [data.meals[0].strIngredient1];
        Ingredient.push(data.meals[0].strIngredient2);
        Ingredient.push(data.meals[0].strIngredient3);
        Ingredient.push(data.meals[0].strIngredient4);
        Ingredient.push(data.meals[0].strIngredient5);
        Ingredient.push(data.meals[0].strIngredient6);
        Ingredient.push(data.meals[0].strIngredient7);
        Ingredient.push(data.meals[0].strIngredient8);
        Ingredient.push(data.meals[0].strIngredient9);
        Ingredient.push(data.meals[0].strIngredient10);
        Ingredient.push(data.meals[0].strIngredient11);
        Ingredient.push(data.meals[0].strIngredient12);
        Ingredient.push(data.meals[0].strIngredient13);
        Ingredient.push(data.meals[0].strIngredient14);
        Ingredient.push(data.meals[0].strIngredient15);
        Ingredient.push(data.meals[0].strIngredient16);
        Ingredient.push(data.meals[0].strIngredient17);
        Ingredient.push(data.meals[0].strIngredient18);
        Ingredient.push(data.meals[0].strIngredient19);
        Ingredient.push(data.meals[0].strIngredient20);
        const filteredIngredient = Ingredient.filter(Boolean);
        // console.log(filteredIngredient);

        let Measure = [data.meals[0].strMeasure1];
        Measure.push(data.meals[0].strMeasure2);
        Measure.push(data.meals[0].strMeasure3);
        Measure.push(data.meals[0].strMeasure4);
        Measure.push(data.meals[0].strMeasure5);
        Measure.push(data.meals[0].strMeasure6);
        Measure.push(data.meals[0].strMeasure7);
        Measure.push(data.meals[0].strMeasure8);
        Measure.push(data.meals[0].strMeasure9);
        Measure.push(data.meals[0].strMeasure10);
        Measure.push(data.meals[0].strMeasure11);
        Measure.push(data.meals[0].strMeasure12);
        Measure.push(data.meals[0].strMeasure13);
        Measure.push(data.meals[0].strMeasure14);
        Measure.push(data.meals[0].strMeasure15);
        Measure.push(data.meals[0].strMeasure16);
        Measure.push(data.meals[0].strMeasure17);
        Measure.push(data.meals[0].strMeasure18);
        Measure.push(data.meals[0].strMeasure19);
        Measure.push(data.meals[0].strMeasure20);
        const filteredMeasure = Measure.filter(Boolean);
        // console.log(filteredMeasure);

        var table = `  
    <div class="relative overflow-x-auto rounded-xl">
    <table class="w-[90%] m-4 text-sm text-left text-gray-500 dark:text-gray-400 ">
      <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
          <th scope="col" class="px-6 py-3">Ingredients</th>
          <th scope="col" class="px-6 py-3">Measures</th>
        </tr>
      </thead>
      <tbody>
`;
        for (index = 0; index < filteredIngredient.length; index++) {
          table += `
    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
      <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">${filteredIngredient[index]}</th>
      <td class="px-6 py-4">${filteredMeasure[index]}</td>
    </tr>
  `;
        }
        table += `</tbody></table></div>`;
        // GenratePDF(data.meals[0]);
        modal.innerHTML = "";
        modal.innerHTML = `
      <div class="modal-content">
      

      <div class="flex justify-center items-center w-full h-full max-w-2xl md:h-auto">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
          <!-- Modal header -->
          <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
          <h4 class="text-2xl font-bold dark:text-white">
          ${data.meals[0].strMeal}
            </h4>
            <button type="button" onclick="Close()"
              class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
              data-modal-hide="defaultModal">
              <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                  clip-rule="evenodd"></path>
              </svg>
              <span i class="sr-only">&times;</span>
            </button>
          </div>
          <!-- Modal body -->
          <div class="p-6 space-y-6">
            <h5 class="text-xl font-bold dark:text-white">Instructions</h5>
           
            <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            ${data.meals[0].strInstructions}
            </p>
            ${table}
    
          </div>
          <div class="flex justify-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600">
          <a href=" ${data.meals[0].strYoutube}"class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Open Video</a>
          <a href=" ${data.meals[0].strSource}"class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Open Source</a>
          <a id="download" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">
            <svg aria-hidden="true" class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M5 4v3H4a2 2 0 00-2 2v3a2 2 0 002 2h1v2a2 2 0 002 2h6a2 2 0 002-2v-2h1a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0H7v3h6V4zm0 8H7v4h6v-4z" clip-rule="evenodd"></path></svg>
            <span class="sr-only">Print</span>
          </a>

        </div>
        </div>
      </div>

      
      `;
      //To download PDF
      $('#download').click(()=>{GenratePDF(data.meals[0])});
        modal.style.display = "block";
      }
    
  );
}
// When the user clicks on (x), close the modal
function Close() {
  // console.log("Closing modal");
  var modal = document.getElementById("myModal");
  modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

function GenratePDF(meal) {
  let Ingredient = [meal.strIngredient1];
  Ingredient.push(meal.strIngredient2);
  Ingredient.push(meal.strIngredient3);
  Ingredient.push(meal.strIngredient4);
  Ingredient.push(meal.strIngredient5);
  Ingredient.push(meal.strIngredient6);
  Ingredient.push(meal.strIngredient7);
  Ingredient.push(meal.strIngredient8);
  Ingredient.push(meal.strIngredient9);
  Ingredient.push(meal.strIngredient10);
  Ingredient.push(meal.strIngredient11);
  Ingredient.push(meal.strIngredient12);
  Ingredient.push(meal.strIngredient13);
  Ingredient.push(meal.strIngredient14);
  Ingredient.push(meal.strIngredient15);
  Ingredient.push(meal.strIngredient16);
  Ingredient.push(meal.strIngredient17);
  Ingredient.push(meal.strIngredient18);
  Ingredient.push(meal.strIngredient19);
  Ingredient.push(meal.strIngredient20);
  const filteredIngredient = Ingredient.filter(Boolean);
  // console.log(filteredIngredient);

  let Measure = [meal.strMeasure1];
  Measure.push(meal.strMeasure2);
  Measure.push(meal.strMeasure3);
  Measure.push(meal.strMeasure4);
  Measure.push(meal.strMeasure5);
  Measure.push(meal.strMeasure6);
  Measure.push(meal.strMeasure7);
  Measure.push(meal.strMeasure8);
  Measure.push(meal.strMeasure9);
  Measure.push(meal.strMeasure10);
  Measure.push(meal.strMeasure11);
  Measure.push(meal.strMeasure12);
  Measure.push(meal.strMeasure13);
  Measure.push(meal.strMeasure14);
  Measure.push(meal.strMeasure15);
  Measure.push(meal.strMeasure16);
  Measure.push(meal.strMeasure17);
  Measure.push(meal.strMeasure18);
  Measure.push(meal.strMeasure19);
  Measure.push(meal.strMeasure20);
  const filteredMeasure = Measure.filter(Boolean);
  // console.log(filteredMeasure);

  var table = `  
    <div class="relative overflow-x-auto rounded-xl">
    <table class="w-[90%] m-4 text-sm text-left text-gray-500 dark:text-gray-400 ">
      <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
          <th scope="col" class="px-6 py-3">Ingredients</th>
          <th scope="col" class="px-6 py-3">Measures</th>
        </tr>
      </thead>
      <tbody>
`;
  for (index = 0; index < filteredIngredient.length; index++) {
    table += `
    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
      <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">${filteredIngredient[index]}</th>
      <td class="px-6 py-4">${filteredMeasure[index]}</td>
    </tr>
  `;
  }
  table += `</tbody></table></div>`;

  var myWindow = window.open("", "_blank");
  myWindow.document.write(`

  <!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <title>${meal.strMeal}</title>
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
      />
      <link rel="icon" type="image/x-icon" href="assets/pie.png" />
      
      <!-- html2pdf And TailWind link -->
      <script src="js/html2pdf.js"></script>
      <link rel="stylesheet" href="css/tailwind.css" />
      <style>
table, th, td {
border:1px solid black;
}
</style>
    </head>
    <body class="w-full flex justify-center items-center flex-col">
      <button id="download-button" type="button" class="m-8 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Download as PDF</button>

      <div id="invoice" class="m-4">
        <a href="#" class="flex items-center">
          <img src="assets/pie.png" class="h-8 mr-3" alt="Recipe Heaven Logo" />
          <span class="self-center text-2xl font-semibold whitespace-nowrap">Recipe Heaven</span>
        </a>
        <hr class=" max-w-3xl h-px my-4 bg-gray-400 border-0">
        <h1 class="text-2xl font-extrabold text-gray-600 mb-3">${meal.strMeal}</h1>
        
        <div class="flex justify-around mb-4">
          <h6 class="text-lg font-bold inline">Category: <p class="mb-3 text-sm text-gray-500 inline">${meal.strCategory}</p></h6>
          <h6 class="text-lg font-bold inline">Area: <p class="mb-3 text-sm text-gray-500 inline">${meal.strArea}</p></h6>  
        </div>

        <h1 class="text-xl font-extrabold text-gray-600 mb-3">Instructions:</h1>

        <p class="max-w-3xl	 mb-3 text-gray-500">${meal.strInstructions}</p>
        ${table}
        <div class="flex justify-around m-4">
        <a href="${meal.strYoutube}" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">YouTube Link</a>
        <a href="${meal.strSource}" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Source Link</a>
        </div>


      </div>
  
      <script>
        const button = document.getElementById('download-button');
  
        function generatePDF() {
          // Choose the element that your content will be rendered to.
          const element = document.getElementById('invoice');
          // Choose the element and save the PDF for your user.
          html2pdf().from(element).save('${meal.strMeal}');
        }
  
        button.addEventListener('click', generatePDF);
      </script>
    </body>
  </html>
    
    
    
    
    `);
}
